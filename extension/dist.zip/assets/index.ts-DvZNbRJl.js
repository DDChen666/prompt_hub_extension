import{l as a,u as n}from"./indexed-CyISXe9T.js";chrome.runtime.onInstalled.addListener(async()=>{try{const e=await a();if(!e||e.length===0){const t=Date.now();await n({id:"seed-support-1",title:"回覆客訴基礎框架",content:`您好，我們已收到您的反饋，以下是處理步驟...
（請補齊訂單資訊、期望解法、後續聯繫）`,tags:["cs","tone"],group:"support",favorite:!1,updatedAt:t}),await n({id:"seed-eng-1",title:"技術 Bug 回報模板",content:`環境：
版本：
重現步驟：
期望行為：
實際行為：
附加資訊：`,tags:["eng","bug"],group:"engineering",favorite:!1,updatedAt:t})}}catch(e){console.warn("seed failed",e)}});console.info("Prompt Organizer SW ready");
